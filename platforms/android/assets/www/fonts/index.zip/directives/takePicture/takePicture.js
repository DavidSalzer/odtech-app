torScoreApp.directive('takePicture', ['$state', '$rootScope', function ($state, $rootScope) {
    return {
        restrict: 'E',
        templateUrl: './directives/takePicture/takePicture.html',
        link: function (scope, el, attrs) {
     
        },
        replace: true
    };


} ]);