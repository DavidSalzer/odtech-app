var torScoreApp = angular.module('torScoreApp', ['ui.router','ui.bootstrap'])

/**** UI Router ****/
.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/login");

    $stateProvider
		.state("login", {
		    url: "/login",
		    views: {
		        "main": {
		            templateUrl: "components/login/login.html",
		            controller: "login"
		        }
		    }
		})
        .state("welcome", {
            url: "/welcome",
            views: {
                "main": {
                    templateUrl: "components/welcome/welcome.html",
                    controller: "welcome"
                }
            }
        })
        .state("categoryReport", {
            url: "/categoryReport",
            views: {
                "main": {
                    templateUrl: "components/categoryReport/categoryReport.html",
                    controller: "categoryReport"
                }
            }
        })
        
});
